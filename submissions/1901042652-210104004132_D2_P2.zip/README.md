# Recipix v4.1 — Implementation (Part 2)

**Course:** CSE 341 — Concepts of Programming Languages
**Institution:** Gebze Technical University, Spring 2026
**Team:** Berk Hakan Öge (210104004132) · İsmail Kabak (1901042652)
**Submission:** Part 2 — 22 May 2026, 23:59
**Language:** Recipix v4.1 — domain-specific language for parameterized
recipes with dimensional types.

---

## 1. Quick start

No third-party dependencies — Python 3.11+ and the standard library are
all you need.

```bash
# Parse only — exits 0 on success, prints OK; exits 1 on parse error.
python main.py src/tests/fixtures/valid/sample1.rcx

# Type-check only — parse + type check. Exits 0 if well-typed.
python main.py --typecheck src/tests/fixtures/valid/sample1.rcx

# Run end-to-end — parse + type check + interpret + render.
python main.py --run src/tests/fixtures/valid/sample1.rcx
python main.py --run src/tests/fixtures/valid/sample2.rcx

# Type-check the dimension-mismatch sample (exits 1 with a real
# type-error message — this is the D3 [P2] demonstration program).
python main.py --typecheck src/tests/fixtures/valid/sample3.rcx

# Run the full test suite (152 tests, all passing at submission).
python -m unittest discover src/tests

# Dump the AST of any program (useful for debugging).
python main.py --dump-ast src/tests/fixtures/valid/sample1.rcx
```

Run all commands from the **project root** (the directory containing
`main.py`).

---

## 2. What this is

Recipix is a small DSL for describing, parameterizing, scaling, and
substituting recipes. Every ingredient quantity carries a dimension
(`Mass`, `Volume`, `Count`, `Temperature`, `Duration`); the type system
enforces dimensional correctness at compile time. The language has
parameterized recipes, scalar helper functions, conditionals,
count-bounded and iterator loops, lists, and three call-site-only
domain operations: `evaluate`, `scale`, and `substitute`.

A small example:

```recipix
function half(n: int) -> int { return n / 2 }

recipe pancakes(servings: int) serves servings {
    ingredient flour : 50 g * servings
    ingredient milk  : 60 ml * servings
    ingredient eggs  : half(servings) * 1 count
    ingredient salt  : 1 pinch

    step "Mix dry"     { combine(flour, salt) }
    step "Add wet"     { combine(milk, eggs) }
    step "Cook batches" at 180 °C for 3 min {
        repeat servings times { pour(milk) flip() }
    }
}

evaluate scale(pancakes(servings: 4), by: 1.5)
```

The locked language specification is at `docs/recipix_v4_1_spec.md`. The
joint design contract between the two implementation halves is at
`part2_plan.md`. The Part 2 written deliverables (D1 design spec, D3
test report) are PDFs in the separate `P2_docs` submission.

---

## 3. Repository layout

```
.
├── main.py                                # CLI entry point
├── part2_plan.md                          # Joint Part 2 contract (Rev 3)
├── docs/
│   ├── recipix_v4_1_spec.md               # Locked language specification
│   ├── ISMAIL_GUIDE.md                    # Type-checker build guide
│   ├── CSE341_Project_Handout.pdf         # Course handout
│   ├── CSE341_Submission_Guide.pdf        # Submission guide
│   ├── 210104004132_D4_P2.md              # AI usage journal continuation (Berk)
│   ├── 210104004132_D5_P2.md              # Retrospective + self-assessment (Berk)
│   ├── D1_P2_Berk_sections.md             # Working draft of Berk's D1 sections
│   ├── D3_P2_Berk_sections.md             # Working draft of Berk's D3 sections
│   └── Deprecated/                        # Part 1 deliverables (audit trail)
└── src/
    ├── lexer.py                           # Hand-written lexer (Part 1)
    ├── recipix/
    │   ├── __init__.py                    # Public surface: parse, check, run
    │   ├── __main__.py                    # CLI dispatcher (--typecheck, --run, --dump-ast)
    │   ├── tokens.py                      # Token type constants
    │   ├── ast_nodes.py                   # All AST dataclasses
    │   ├── parser.py                      # Recursive-descent parser (Part 1)
    │   ├── pretty.py                      # AST pretty-printer
    │   ├── errors.py                      # ParseError, TypeCheckError, RuntimeRecipixError
    │   ├── environment.py                 # Lexical-scope environment chain (joint)
    │   ├── runtime_values.py              # Runtime value dataclasses + unit normalization
    │   ├── typechecker.py                 # Type checker — all 19 spec §10 errors
    │   ├── interpreter.py                 # Tree-walking interpreter
    │   └── rendering.py                   # Recipe output renderer
    └── tests/
        ├── test_lexer.py                  # Lexer unit tests
        ├── test_parser.py                 # Parser unit tests (48 tests)
        ├── test_interpreter.py            # Interpreter unit tests (36+ tests)
        ├── test_regression.py             # Regression harness over fixtures
        ├── fixtures/
        │   ├── valid/    sample1, sample2, sample3.rcx
        │   └── invalid/  five parse-error fixtures
        └── regression/
            ├── should_pass/
            ├── should_fail/
            ├── exploratory/
            └── stress/
```

---

## 4. Architecture

Recipix is a four-phase compiler/interpreter pipeline:

```
source → lexer → parser → type checker → interpreter → rendered output
```

Each phase is in its own module, with no circular dependencies:

| Phase | Module | Owner | Lines |
|---|---|---|---|
| Lex  | `src/lexer.py`                | İsmail (P1)   | ~330 |
| Parse | `src/recipix/parser.py`      | Berk (P1)     | ~700 |
| Type-check | `src/recipix/typechecker.py` | İsmail (P2) | ~700 |
| Interpret  | `src/recipix/interpreter.py` | Berk (P2)   | ~700 |
| Render     | `src/recipix/rendering.py`   | Berk (P2)   | ~100 |

Shared infrastructure used by both type checker and interpreter:

- `src/recipix/environment.py` — type-agnostic lexical-scope chain
  with `define`, `lookup`, `declare_check`, and `has_local`. The type
  checker stores type strings as values; the interpreter stores
  runtime values from `runtime_values.py`. Same scoping logic, no
  duplication.
- `src/recipix/runtime_values.py` — pure-data dataclasses
  (`RtQuantity`, `RtPinch`/`PINCH`, `RtIngredient`, `RtRecipe`,
  `RtList`) plus the `UNIT_TABLE` for normalizing quantities to
  base units (g, ml, count, °C, min).
- `src/recipix/errors.py` — the three sibling exception types, one
  per language phase: `ParseError`, `TypeCheckError`,
  `RuntimeRecipixError`. All format consistently as
  `<phase> error at line L, col C: <message>`.

The type checker rewrites every `AmbiguousCall` AST node in place to
either a `FunctionCall` or `RecipeCall` via symbol-table lookup (plan
§2.1). The interpreter assumes this rewrite has happened — if it sees
an `AmbiguousCall` at runtime, it raises a loud `RuntimeRecipixError`
naming the integration bug.

---

## 5. Spec §10 errors — coverage map

The type checker enforces all 19 compile-time errors from spec §10 plus
the plan-§2.6 single-return rule. Code locations:

| #  | Error | File / method |
|----|---|---|
|  1 | Dimension mismatch in `BinaryOp` / `CompareOp` / `SubstituteCall` | `typechecker.py::_check_BinaryOp`, `_check_CompareOp`, `_check_SubstituteCall` |
|  2 | `Pinch` in arithmetic / comparison / scaling                     | `typechecker.py::_reject_pinch` |
|  3 | Heterogeneous list literal                                       | `typechecker.py::_check_ListLit` |
|  4 | Unknown identifier                                               | `typechecker.py::_check_Identifier`, `_check_AmbiguousCall`, `_check_FunctionCall`, `_check_RecipeCall` |
|  5 | Single-assignment violation (re-declare in same scope)           | `typechecker.py::_declare` |
|  6 | Shadowing (re-declare visible from any ancestor scope)           | `typechecker.py::_declare` (`ShadowingError`) |
|  7 | Non-`bool` in `if` condition                                     | `typechecker.py::_check_IfStmt` |
|  8 | Non-`int` in `repeat` count                                      | `typechecker.py::_check_RepeatStmt` |
|  9 | Non-list in `foreach` source                                     | `typechecker.py::_check_ForeachStmt` |
| 10 | Non-`Temperature` in step `at` modifier                          | `typechecker.py::_check_StepDecl` |
| 11 | Non-`Duration` in step `for` modifier                            | `typechecker.py::_check_StepDecl` |
| 12 | Wrong arity in recipe or function call                           | `typechecker.py::_check_FunctionCall`, `_check_RecipeCall`, `_check_ActionStmt` |
| 13 | Wrong argument types in recipe / function call / action verbs    | `typechecker.py::_check_FunctionCall`, `_check_RecipeCall`, `_check_ActionStmt` |
| 14 | `substitute` of unknown ingredient                               | `typechecker.py::_check_SubstituteCall` |
| 15 | `float → int` coercion attempt                                   | `typechecker.py::_check_LetStmt`, `_check_FunctionCall`, `_check_RecipeCall` |
| 16 | `substitute` swaps `Pinch ↔ Quantity`                            | `typechecker.py::_check_SubstituteCall` |
| 17 | Non-IDENT in `substitute` slot                                   | parser (`parser.py::_parse_substitute_call`) |
| 18 | `quantity_of` on non-`Ingredient`                                | `typechecker.py::_check_QuantityOf` |
| 19 | `return` not as last statement of function body (plan §2.6)      | `typechecker.py::_check_single_return` |

Five runtime errors (spec §10 runtime list) are enforced by the
interpreter:

| Error | Module |
|---|---|
| Negative `repeat` count                       | `interpreter.py::_eval_RepeatStmt` |
| Negative or zero `scale.by`                   | `interpreter.py::_eval_ScaleCall` |
| Division by zero in scalar arithmetic         | `interpreter.py::_eval_BinaryOp` |
| `substitute` of unknown ingredient at run time (rare — usually caught by #14) | `interpreter.py::_eval_SubstituteCall` |

---

## 6. Action-verb signature table

The twelve action verbs are partitioned into three signature classes
(plan §2.3, codified as `HETEROGENEOUS_VERBS`, `HOMOGENEOUS_VERBS`,
`NULLARY_VERBS` in `typechecker.py`):

| Class | Verbs | Rule |
|---|---|---|
| **Heterogeneous** | `combine`, `mix`, `add`, `sprinkle` | ≥1 argument; each arg is `Ingredient` (any dimension, including `Pinch`) or bare `Quantity`. Mixed dimensions OK — decision #29 carve-out. |
| **Homogeneous**   | `pour`, `drizzle`, `whisk`, `blend`, `knead`, `melt` | ≥1 argument; all args share one dimension; `Pinch` forbidden. Implicit Ingredient→Quantity projection (decision #31) applies. |
| **Nullary**       | `bake`, `flip` | 0 arguments. `at` / `for` step modifiers carry any parameters. |

---

## 7. Tests

Run the full suite from the project root:

```bash
python -m unittest discover src/tests
```

At submission this reports **152 / 152 passing, 0 failures, 0 errors**.

Test files:

| File | Coverage |
|---|---|
| `src/tests/test_lexer.py`        | Lexer unit tests for token categories, two-token quantity literals, error reporting. |
| `src/tests/test_parser.py`       | 48 parser tests covering every grammar production and every grammar-level decision (#7, #17, #20, #23, #34, #35). |
| `src/tests/test_interpreter.py`  | 36+ interpreter tests covering arithmetic, quantity normalization, recipe instantiation, `scale`, `substitute`, runtime errors, implicit Ingredient→Quantity projection. |
| `src/tests/test_regression.py`   | Regression harness that walks `src/tests/regression/should_pass/`, `should_fail/`, and `exploratory/` and runs each fixture through the appropriate phase. |

Fixture directories:

- `src/tests/fixtures/valid/`     — three locked sample programs from spec §11.
- `src/tests/fixtures/invalid/`   — five parse-error fixtures from D3 [P1].
- `src/tests/regression/should_pass/` — fixtures the parser must accept.
- `src/tests/regression/should_fail/` — fixtures the parser must reject.
- `src/tests/regression/exploratory/` — extra fixtures for the Part 2 testbed.
- `src/tests/regression/stress/`  — stress fixtures (deep parens, etc.); skipped by default.

---

## 8. Locked language decisions cited in this README

Recipix's design is governed by 35 numbered decisions in
`docs/recipix_v4_1_spec.md` §12. The ones most visible at the grammar
and run-time levels:

- **#7** — Quantity literals are two tokens (numeric literal followed
  by unit keyword), separated by whitespace and/or `//` comments only.
- **#10** — Split type-equivalence rule: structural for `Quantity<D>`,
  `Ingredient`, and `List<T>`; name equivalence for `Recipe`.
- **#17** — Comparison operators are non-associative; `a < b < c` is a
  parse error, not a type error.
- **#20** — `if` and `else` blocks require braces; dangling-else
  eliminated by construction.
- **#23** — Step modifier order is fixed: `at` before `for`, each at
  most once.
- **#25** — `scale` and `substitute` are functional; they produce
  fresh `RtRecipe` values without mutating the original.
- **#27** — Assignment is a statement, not an expression. `let` is the
  only binding form.
- **#28** — Ingredient identity is the symbol-table binding, not the
  `name` field's contents.
- **#29** — Action verbs are an exception to the homogeneous-list
  rule. The three-class table (plan §2.3) captures the carve-out.
- **#31** — When an `Ingredient` appears in arithmetic, comparison,
  or substitution context, it implicitly projects to its
  `quantity` field. Equivalent explicit form: `quantity_of(<ingredient>)`.
- **#34** — `quantity_of` is a unary operator at level 1, not a
  function. Cannot be redefined, assigned, or passed as a value.
- **#35** — The two ingredient slots in `substitute` are bare `IDENT`
  terminals in the grammar, not `<expr>`. The parser refuses
  computed expressions in those positions.

---

## 9. CLI flags

| Flag | Behavior |
|---|---|
| (none)         | Parse only. Print `OK — parsed <file>` on success. |
| `--dump-ast`   | Parse + pretty-print the AST to stdout. |
| `--typecheck`  | Parse + type-check. Print `OK — type-checked <file>` on success; otherwise print a `type error at line L, col C: <message>` and exit 1. |
| `--run`        | Parse + type-check + interpret. Print the rendered output of every `evaluate` statement to stdout. |

All four flags can be combined with the file path as the only
positional argument.

---

## 10. Authors and acknowledgments

- **Berk Hakan Öge (210104004132)** — Lexer integration, parser
  (Part 1), interpreter, rendering (Part 2), §4.3 / §4.4 / §4.7 /
  partial §4.8 of D1.
- **İsmail Kabak (1901042652)** — Lexer (Part 1), type checker (Part 2),
  §4.1 / §4.2 / §4.5 / §4.6 / partial §4.8 of D1.
- **AI assistance** — Documented in the per-student D4 AI usage
  journals (Berk: `docs/210104004132_D4_P2.md`; İsmail submits his own).

This project uses no third-party dependencies. The implementation is
pure Python 3.11+ and the standard library. Tested on Windows (CPython
3.13). The unit-conversion table, type-equivalence split, action-verb
classification, and the three-class verb table are documented in the
spec and the plan; this code implements those decisions, it does not
introduce them.

---

## 11. License

Submitted as coursework for CSE 341 Spring 2026 at Gebze Technical
University. No external license is granted; the repository is private
to the course.
