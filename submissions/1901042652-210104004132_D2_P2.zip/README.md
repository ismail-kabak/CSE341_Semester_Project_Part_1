# Recipix v4.1 — Implementation (Part 2)

**Course:** CSE 341 — Concepts of Programming Languages
**Institution:** Gebze Technical University, Spring 2026
**Team:** Berk Hakan Öge (210104004132) · İsmail Kabak (1901042652)
**Submission:** Part 2 — 22 May 2026

Recipix is a domain-specific language for parameterized recipes with
dimensional types. Every ingredient quantity carries a dimension
(`Mass`, `Volume`, `Count`, `Temperature`, `Duration`), and the type
system enforces dimensional correctness at compile time.

---

## Quick start

No third-party dependencies — Python 3.11+ and the standard library
are all you need.

```bash
# Parse only — prints OK on success; exits 1 on parse error.
python main.py src/tests/fixtures/valid/sample1.rcx

# Type-check only — parse + type check.
python main.py --typecheck src/tests/fixtures/valid/sample1.rcx

# Run end-to-end — parse + type check + interpret + render.
python main.py --run src/tests/fixtures/valid/sample1.rcx
python main.py --run src/tests/fixtures/valid/sample2.rcx

# Type-check the dimension-mismatch sample (exits 1 with a real
# type-error message — the D3 demonstration program).
python main.py --typecheck src/tests/fixtures/valid/sample3.rcx

# Run the full test suite (152 tests at submission, all green).
python -m unittest discover src/tests

# Dump the AST of any program (debugging aid).
python main.py --dump-ast src/tests/fixtures/valid/sample1.rcx
```

Run all commands from the **project root** (the directory containing
`main.py`).

---

## CLI flags

| Flag | Behavior |
|---|---|
| (none)         | Parse only. Print `OK — parsed <file>` on success. |
| `--dump-ast`   | Parse + pretty-print the AST to stdout. |
| `--typecheck`  | Parse + type-check. Print `OK — type-checked <file>` on success; otherwise print `type error at line L, col C: <message>` and exit 1. |
| `--run`        | Parse + type-check + interpret. Print the rendered output of every `evaluate` statement to stdout. Runtime errors print `runtime error at line L: <message>` and exit 1. |

---

## Repository layout

```
.
├── main.py                                # CLI entry point
├── README.md                              # this file
└── src/
    ├── lexer.py                           # Hand-written lexer
    ├── recipix/
    │   ├── __init__.py                    # Public surface: parse, check, run
    │   ├── __main__.py                    # CLI dispatcher (--typecheck, --run, --dump-ast)
    │   ├── tokens.py                      # Token type constants
    │   ├── ast_nodes.py                   # All AST dataclasses
    │   ├── parser.py                      # Recursive-descent parser
    │   ├── pretty.py                      # AST pretty-printer
    │   ├── errors.py                      # ParseError, TypeCheckError, RuntimeRecipixError
    │   ├── environment.py                 # Lexical-scope environment chain
    │   ├── runtime_values.py              # Runtime value dataclasses + unit normalization
    │   ├── typechecker.py                 # Type checker — all 19 spec §10 errors
    │   ├── interpreter.py                 # Tree-walking interpreter
    │   └── rendering.py                   # Recipe output renderer
    └── tests/
        ├── test_lexer.py
        ├── test_parser.py                 # 48 parser tests
        ├── test_interpreter.py            # 36+ interpreter tests
        ├── test_regression.py             # Regression harness over fixtures
        ├── fixtures/
        │   ├── valid/    sample1, sample2, sample3.rcx
        │   └── invalid/  five parse-error fixtures
        └── regression/
            ├── should_pass/
            ├── should_fail/
            ├── exploratory/
            └── stress/
```

---

## Architecture

Recipix is a four-phase compiler/interpreter pipeline:

```
source → lexer → parser → type checker → interpreter → rendered output
```

Each phase has its own module with no circular dependencies:

| Phase       | Module                          | Lines |
|---|---|---|
| Lex         | `src/lexer.py`                  | ~330  |
| Parse       | `src/recipix/parser.py`         | ~700  |
| Type-check  | `src/recipix/typechecker.py`    | ~700  |
| Interpret   | `src/recipix/interpreter.py`    | ~700  |
| Render      | `src/recipix/rendering.py`      | ~100  |

Shared infrastructure used by both type checker and interpreter:

- **`src/recipix/environment.py`** — type-agnostic lexical-scope chain
  (`define`, `lookup`, `declare_check`, `has_local`). The type checker
  stores type strings; the interpreter stores runtime values from
  `runtime_values.py`. Same scoping logic, no duplication.
- **`src/recipix/runtime_values.py`** — pure-data dataclasses
  (`RtQuantity`, `RtPinch`/`PINCH`, `RtIngredient`, `RtRecipe`,
  `RtList`) plus the `UNIT_TABLE` for normalizing quantities to base
  units (`g`, `ml`, `count`, `°C`, `min`).
- **`src/recipix/errors.py`** — three sibling exception types, one
  per language phase. All format consistently as
  `<phase> error at line L, col C: <message>`.

The type checker rewrites every `AmbiguousCall` AST node in place to
either a `FunctionCall` or `RecipeCall` via symbol-table lookup. The
interpreter assumes this rewrite has happened — if it sees an
`AmbiguousCall` at runtime, it raises a loud `RuntimeRecipixError`
naming the integration bug.

---

## Compile-time errors (spec §10)

The type checker enforces 19 compile-time errors. Source locations:

| #  | Error | File / method |
|----|---|---|
|  1 | Dimension mismatch in arithmetic / comparison / substitute | `typechecker.py::_check_BinaryOp`, `_check_CompareOp`, `_check_SubstituteCall` |
|  2 | Pinch in arithmetic / comparison / scaling                 | `typechecker.py::_reject_pinch` |
|  3 | Heterogeneous list literal                                 | `typechecker.py::_check_ListLit` |
|  4 | Unknown identifier                                         | `typechecker.py::_check_Identifier`, `_check_FunctionCall`, `_check_RecipeCall` |
|  5 | Single-assignment violation                                | `typechecker.py::_declare` |
|  6 | Shadowing                                                  | `typechecker.py::_declare` (ShadowingError) |
|  7 | Non-`bool` in `if` condition                               | `typechecker.py::_check_IfStmt` |
|  8 | Non-`int` in `repeat` count                                | `typechecker.py::_check_RepeatStmt` |
|  9 | Non-list in `foreach` source                               | `typechecker.py::_check_ForeachStmt` |
| 10 | Non-`Temperature` in step `at` modifier                    | `typechecker.py::_check_StepDecl` |
| 11 | Non-`Duration` in step `for` modifier                      | `typechecker.py::_check_StepDecl` |
| 12 | Wrong arity in recipe / function / action call             | `typechecker.py::_check_FunctionCall`, `_check_RecipeCall`, `_check_ActionStmt` |
| 13 | Wrong argument types                                       | `typechecker.py::_check_FunctionCall`, `_check_RecipeCall`, `_check_ActionStmt` |
| 14 | `substitute` of unknown ingredient                         | `typechecker.py::_check_SubstituteCall` |
| 15 | `float → int` coercion attempt                             | `typechecker.py::_check_LetStmt`, `_check_FunctionCall`, `_check_RecipeCall` |
| 16 | `substitute` swaps Pinch ↔ Quantity                        | `typechecker.py::_check_SubstituteCall` |
| 17 | Non-IDENT in `substitute` slot                             | parser (`parser.py::_parse_substitute_call`) |
| 18 | `quantity_of` on non-`Ingredient`                          | `typechecker.py::_check_QuantityOf` |
| 19 | `return` not as last statement of a function body          | `typechecker.py::_check_single_return` |

Five runtime errors are enforced by the interpreter: negative `repeat`
count, negative or zero `scale.by`, division by zero in scalar
arithmetic, `substitute` of an unknown ingredient at run time (rare —
usually caught by error #14 at compile time), and an internal-error
guard on `AmbiguousCall` reaching the interpreter.

---

## Action-verb signature table

The twelve action verbs are partitioned into three signature classes
(`HETEROGENEOUS_VERBS`, `HOMOGENEOUS_VERBS`, `NULLARY_VERBS` in
`typechecker.py`):

| Class | Verbs | Rule |
|---|---|---|
| **Heterogeneous** | `combine`, `mix`, `add`, `sprinkle` | ≥1 argument; each arg is `Ingredient` (any dimension, including `Pinch`) or bare `Quantity`. Mixed dimensions OK. |
| **Homogeneous**   | `pour`, `drizzle`, `whisk`, `blend`, `knead`, `melt` | ≥1 argument; all args share one dimension; `Pinch` forbidden. Implicit Ingredient→Quantity projection applies. |
| **Nullary**       | `bake`, `flip` | 0 arguments. `at` / `for` step modifiers carry any parameters. |

---

## Tests

```bash
python -m unittest discover src/tests
```

At submission this reports **152 / 152 passing, 0 failures, 0 errors**.

Test files:

| File | Coverage |
|---|---|
| `src/tests/test_lexer.py`       | Lexer unit tests for token categories and two-token quantity literals. |
| `src/tests/test_parser.py`      | 48 parser tests covering every grammar production. |
| `src/tests/test_interpreter.py` | 36+ interpreter tests covering arithmetic, quantity normalization, recipe instantiation, `scale`, `substitute`, runtime errors, implicit Ingredient→Quantity projection. |
| `src/tests/test_regression.py`  | Regression harness walking `src/tests/regression/should_pass/`, `should_fail/`, and `exploratory/`. |

Fixture directories:

- `src/tests/fixtures/valid/`     — three locked sample programs.
- `src/tests/fixtures/invalid/`   — five parse-error fixtures.
- `src/tests/regression/should_pass/` — fixtures the parser must accept.
- `src/tests/regression/should_fail/` — fixtures the parser must reject.
- `src/tests/regression/exploratory/` — extra fixtures for the Part 2 testbed.
- `src/tests/regression/stress/`  — stress fixtures; skipped by default.

---

## Authors

- **Berk Hakan Öge (210104004132)** — parser (Part 1), interpreter,
  rendering (Part 2).
- **İsmail Kabak (1901042652)** — lexer (Part 1), type checker (Part 2).

This project uses no third-party dependencies. Tested on Windows
(CPython 3.13). Submitted as coursework for CSE 341 Spring 2026 at
Gebze Technical University.
